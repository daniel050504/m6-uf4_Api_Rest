package com.daniel_aguado.gestioCoches;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestioCochesApplicationTests {

	@Test
	void contextLoads() {
	}

}

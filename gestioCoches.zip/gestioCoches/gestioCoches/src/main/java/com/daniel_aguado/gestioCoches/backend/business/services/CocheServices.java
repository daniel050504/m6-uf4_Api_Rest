package com.daniel_aguado.gestioCoches.backend.business.services;

import java.util.List;
import java.util.Optional;

import com.daniel_aguado.gestioCoches.backend.business.model.Coche;

public interface CocheServices {

	Long create(Coche coche);	    // C
	Optional<Coche> read(Long numBastidor);   // R
	
	List<Coche> getAll();
	
}

package com.daniel_aguado.gestioCoches.backend.business.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

public class Coche implements Serializable {	
	
	private Long id;
	private String marca;
	private String modelo;
	private String descripcion;
	private Double precio;
	private int cv;
	private int numBastidor;
	private boolean descatalogado;
	
	public Coche() {
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Double getPrecio() {
		return precio;
	}

	public void setPrecio(Double precio) {
		this.precio = precio;
	}

	public int getCv() {
		return cv;
	}

	public void setCv(int cv) {
		this.cv = cv;
	}	

	public int getNumBastidor() {
		return numBastidor;
	}

	public void setNumBastidor(int numBastidor) {
		this.numBastidor = numBastidor;
	}

	public boolean isDescatalogado() {
		return descatalogado;
	}

	public void setDescatalogado(boolean descatalogado) {
		this.descatalogado = descatalogado;
	}
		
	@Override
	public int hashCode() {
		return Objects.hash(id, numBastidor);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Coche other = (Coche) obj;
		return Objects.equals(id, other.id) && numBastidor == other.numBastidor;
	}

	@Override
	public String toString() {
		return "Coche [id=" + id + ", marca=" + marca + ", modelo=" + modelo + ", descripcion=" + descripcion
				+ ", precio=" + precio + ", cv=" + cv + ", numBastidor=" + numBastidor + ", descatalogado="
				+ descatalogado + "]";
	}
	
}

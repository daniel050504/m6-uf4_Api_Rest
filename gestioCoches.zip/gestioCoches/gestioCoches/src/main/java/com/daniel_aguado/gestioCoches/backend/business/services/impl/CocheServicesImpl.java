package com.daniel_aguado.gestioCoches.backend.business.services.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;

import org.springframework.stereotype.Service;

import com.daniel_aguado.gestioCoches.backend.business.model.Coche;
import com.daniel_aguado.gestioCoches.backend.business.services.CocheServices;

@Service
public class CocheServicesImpl implements CocheServices {

	private final TreeMap<Long, Coche> COCHES = new TreeMap<>();
	
	public CocheServicesImpl() {
		init();
	}
	
	@Override
	public Long create(Coche coche) {
		
		Long id = COCHES.lastKey() + 1;
		
		coche.setId(id);
		
		COCHES.put(coche.getId(), coche);
		
		return id;
	}

	@Override
	public Optional<Coche> read(Long id) {
		return Optional.ofNullable(COCHES.get(id));
	}

	@Override
	public List<Coche> getAll() {
		return new ArrayList<>(COCHES.values());
	}
	
	// ***************************************************************
	//
	// Private Methods
	//
	// ***************************************************************

	private void init() {
		
		Coche p1 = new Coche();
		Coche p2 = new Coche();
		Coche p3 = new Coche();
		
		p1.setId(10L);
		p1.setMarca("marca1");
		p1.setModelo("modelo1");
		p1.setDescripcion("Coche potente");
		p1.setPrecio(150.0);
		p1.setCv(150);
		p1.setNumBastidor(1234);
		p1.setDescatalogado(false);
		
		
		p2.setId(20L);
		p2.setMarca("marca2");
		p2.setModelo("modelo2");
		p2.setDescripcion("Coche no potente");
		p2.setPrecio(50.0);
		p2.setCv(50);
		p2.setNumBastidor(5678);
		p2.setDescatalogado(true);
		
		p3.setId(30L);
		p3.setMarca("marca3");
		p3.setModelo("modelo3");
		p3.setDescripcion("Coche super potente");
		p3.setPrecio(50.0);
		p3.setCv(400);
		p3.setNumBastidor(4321);
		p3.setDescatalogado(false);
		
		COCHES.put(p1.getId(), p1);
		COCHES.put(p2.getId(), p2);
		COCHES.put(p3.getId(), p3);
		
	}
}
